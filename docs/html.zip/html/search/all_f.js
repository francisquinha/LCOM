var searchData=
[
  ['o_5fmake_5fcode',['O_MAKE_CODE',['../group__i8042.html#gae86369a7ba38cafa957c16e7f40e106d',1,'i8042.h']]],
  ['o_5fxpm',['O_xpm',['../letters_8h.html#a6f03ffb146e47e098b536802cd7723d6',1,'letters.h']]],
  ['oemdata',['OemData',['../struct____attribute____.html#aadfe9ed1e112d37eb40f226d1763cf83',1,'__attribute__']]],
  ['oemproductnameptr',['OemProductNamePtr',['../struct____attribute____.html#a6e42bff559c80f421bc9b7d2a31199c2',1,'__attribute__']]],
  ['oemproductrevptr',['OemProductRevPtr',['../struct____attribute____.html#a2e5623b983866cb6ba08ec8ab9e9cf06',1,'__attribute__']]],
  ['oemsoftwarerev',['OemSoftwareRev',['../struct____attribute____.html#abd3b5364844ce7019b91c129b5535f42',1,'__attribute__']]],
  ['oemstringptr',['OemStringPtr',['../struct____attribute____.html#a9614316c95d02eedd886806fdda83a3b',1,'__attribute__']]],
  ['oemvendornameptr',['OemVendorNamePtr',['../struct____attribute____.html#adfa68840d3d6136a22a73debb238904a',1,'__attribute__']]]
];
