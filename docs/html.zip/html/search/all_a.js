var searchData=
[
  ['j_5fmake_5fcode',['J_MAKE_CODE',['../group__i8042.html#ga349708078cc2dc9465d817d8671c24fe',1,'i8042.h']]],
  ['j_5fxpm',['J_xpm',['../letters_8h.html#a6c55b457a9e1dff1d99861013bb5fbd4',1,'letters.h']]]
];
