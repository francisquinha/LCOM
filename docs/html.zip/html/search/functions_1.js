var searchData=
[
  ['bcd2dec',['bcd2dec',['../rtc_8c.html#aa786cd9eaa6155ecd5f471ac9642d21e',1,'bcd2dec(unsigned long bcd):&#160;rtc.c'],['../group__rtc__static.html#gaa786cd9eaa6155ecd5f471ac9642d21e',1,'bcd2dec(unsigned long bcd):&#160;rtc_static.h']]]
];
