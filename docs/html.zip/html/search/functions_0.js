var searchData=
[
  ['add_5fcard',['add_card',['../game_8c.html#a03e6d3c562ebc0b99dd77c45ed898cfa',1,'add_card(Game *game, char *base, unsigned short index):&#160;game.c'],['../group__game__static.html#ga03e6d3c562ebc0b99dd77c45ed898cfa',1,'add_card(Game *game, char *base, unsigned short index):&#160;game_static.h']]],
  ['add_5fcards',['add_cards',['../game_8c.html#a80ef0868b883ecb0fdcac62fa118bb88',1,'add_cards(Game *game):&#160;game.c'],['../group__game__static.html#ga80ef0868b883ecb0fdcac62fa118bb88',1,'add_cards(Game *game):&#160;game_static.h']]],
  ['add_5fcards_5fremove',['add_cards_remove',['../game_8c.html#a2d214963a3001ee43841a230d4db8b25',1,'add_cards_remove(Game *game):&#160;game.c'],['../group__game__static.html#ga2d214963a3001ee43841a230d4db8b25',1,'add_cards_remove(Game *game):&#160;game_static.h']]],
  ['add_5fframe',['add_frame',['../game_8c.html#af363df2113fd758bfbc4f0635c7b5756',1,'add_frame(Game *game, char *base, unsigned short index):&#160;game.c'],['../group__game__static.html#gaf363df2113fd758bfbc4f0635c7b5756',1,'add_frame(Game *game, char *base, unsigned short index):&#160;game_static.h']]]
];
