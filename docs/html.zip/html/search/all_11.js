var searchData=
[
  ['q_5fmake_5fcode',['Q_MAKE_CODE',['../group__i8042.html#gaaff2475b473e5023e85d429597e4355b',1,'i8042.h']]],
  ['q_5fxpm',['Q_xpm',['../letters_8h.html#a8b5afb0f3ccd79166f4a647cfdba9358',1,'letters.h']]]
];
