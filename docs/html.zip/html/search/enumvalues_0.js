var searchData=
[
  ['duel_5fbutton',['DUEL_BUTTON',['../group__menu.html#ggaf409d79c8e5111545791e6b086b7f0b9acbad0034cb3abd20b2e6b6b19cc4bfa2',1,'menu.h']]],
  ['duel_5fmode',['DUEL_MODE',['../group__menu.html#gga46c8a310cf4c094f8c80e1cb8dc1f911ae6a1f031d22caa44b17e76d11d4bd529',1,'menu.h']]]
];
