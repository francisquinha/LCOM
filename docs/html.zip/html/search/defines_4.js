var searchData=
[
  ['video_5fmode',['VIDEO_MODE',['../video__gr_8c.html#a3c5cde2577e877adb5f9827014079dde',1,'video_gr.c']]]
];
