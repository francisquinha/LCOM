var searchData=
[
  ['lm_5falloc',['lm_alloc',['../group__lmlib.html#gae45d971ce2ffcf4dc2677eba033a92cd',1,'lmlib.h']]],
  ['lm_5ffree',['lm_free',['../group__lmlib.html#ga73e89d9c297b7390021fb545513579c6',1,'lmlib.h']]],
  ['lm_5finit',['lm_init',['../group__lmlib.html#ga00a9c17c01e794a6bfc80fc5c6ab1ed1',1,'lmlib.h']]],
  ['load_5fgame',['load_game',['../game_8c.html#a086f823df5d330a94fd72ad18a2ab66d',1,'load_game(Game *game):&#160;game.c'],['../group__game__static.html#ga086f823df5d330a94fd72ad18a2ab66d',1,'load_game(Game *game):&#160;game_static.h']]],
  ['load_5fhighscores',['load_highscores',['../group__highscore.html#ga555c6751d944d9aa0cc247c29f6349df',1,'load_highscores(HighScore *highscores[10]):&#160;highscore.c'],['../group__highscore.html#ga555c6751d944d9aa0cc247c29f6349df',1,'load_highscores(HighScore *highscores[10]):&#160;highscore.c']]]
];
