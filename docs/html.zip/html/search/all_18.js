var searchData=
[
  ['x',['x',['../struct_mouse.html#a7ad96126d6df441afe17a3a68a1fdbc4',1,'Mouse']]],
  ['x_5fmake_5fcode',['X_MAKE_CODE',['../group__i8042.html#gaaf2a6ce4e3b441d070f174373469939f',1,'i8042.h']]],
  ['x_5fxpm',['X_xpm',['../letters_8h.html#a7fb3146e6feb74410b6e94c1ffa04a1a',1,'letters.h']]],
  ['xcharsize',['XCharSize',['../struct____attribute____.html#acac41a300563737d7849a92cd1d5c10b',1,'__attribute__']]],
  ['xresolution',['XResolution',['../struct____attribute____.html#abe48e2b29aa99e813a1447d22711f4f4',1,'__attribute__']]]
];
