var searchData=
[
  ['f_5fmake_5fcode',['F_MAKE_CODE',['../group__i8042.html#ga0823e993896c17f67ba880adfd41c086',1,'i8042.h']]],
  ['f_5fxpm',['F_xpm',['../letters_8h.html#afc2827d96d86ebf3e3611af32932eadf',1,'letters.h']]],
  ['first_5fpacket',['first_packet',['../struct_mouse.html#a53888b0824dd33e0281154cf2b5b6465',1,'Mouse']]],
  ['frame',['frame',['../struct_game_state.html#a322d06a669445cffe027a21f011e4ad0',1,'GameState']]]
];
