var searchData=
[
  ['number_5fcolors',['NUMBER_COLORS',['../video__gr_8c.html#aaf64e8dd5d1f59c2aafef02c68bb2f13',1,'video_gr.c']]]
];
