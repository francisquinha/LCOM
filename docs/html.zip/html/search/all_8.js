var searchData=
[
  ['h_5fmake_5fcode',['H_MAKE_CODE',['../group__i8042.html#ga9cd531226041c57e6f0654fdb26fd7f2',1,'i8042.h']]],
  ['h_5fres',['h_res',['../struct_graphics.html#a1d8fe8611d73835f2d24dd2666a23bbb',1,'Graphics::h_res()'],['../video__gr_8c.html#a43e7e5a0a8f9069e6413b2066ca52f3e',1,'h_res():&#160;video_gr.c']]],
  ['h_5fxpm',['H_xpm',['../letters_8h.html#a1327885063db914979879ce60861d2e6',1,'letters.h']]],
  ['handler',['Handler',['../group__dispatcher.html#ga72e36d7343f18dbe3ad8d6fd9a06add9',1,'dispatcher.h']]],
  ['height',['height',['../struct_graphics.html#aeff063a48bfabd4b35bb7ebf0416a1de',1,'Graphics']]],
  ['highscore',['HighScore',['../struct_high_score.html',1,'HighScore'],['../group__highscore.html',1,'(Global Namespace)']]],
  ['highscore_2ec',['highscore.c',['../highscore_8c.html',1,'']]],
  ['highscore_2eh',['highscore.h',['../highscore_8h.html',1,'']]],
  ['highscores',['highscores',['../struct_game.html#ac7c40be10e5821c64855fae96ce932f4',1,'Game']]],
  ['hint',['hint',['../struct_game_state.html#a81162796b6e9ece59b65f802bb2ea3df',1,'GameState']]],
  ['hint_5fbutton',['HINT_BUTTON',['../group__game.html#gga03bfec859eac87be20f8952c1eb89de0aa5a1dce72bb16bece615719a30e2c230',1,'HINT_BUTTON():&#160;game.h'],['../hint__button_8h.html#a3d1171f08e6912a4cb6eadafe4865810',1,'hint_button():&#160;hint_button.h']]],
  ['hint_5fbutton_2eh',['hint_button.h',['../hint__button_8h.html',1,'']]],
  ['hot_5fbutton',['HOT_BUTTON',['../group__menu.html#ggaf409d79c8e5111545791e6b086b7f0b9a475ed3f55b210402eac7fbe2a8837119',1,'menu.h']]],
  ['hot_5fmode',['HOT_MODE',['../group__menu.html#gga46c8a310cf4c094f8c80e1cb8dc1f911ab4b39953c7aecc072c7246a4c97086c2',1,'menu.h']]],
  ['hours',['hours',['../struct_date_time.html#ab2686a3acd0bdce73bf9ccc9b419c1a9',1,'DateTime::hours()'],['../struct_timer.html#ac8afb0e23196a9330fe3381523d1ef71',1,'Timer::hours()']]]
];
