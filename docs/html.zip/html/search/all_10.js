var searchData=
[
  ['p_5fmake_5fcode',['P_MAKE_CODE',['../group__i8042.html#gac0c70805e8d079be0f975bd5d901a6f2',1,'i8042.h']]],
  ['p_5fxpm',['P_xpm',['../letters_8h.html#a29604c7f6a499bc2438657ba9470183b',1,'letters.h']]],
  ['pause_5fbutton',['PAUSE_BUTTON',['../group__game.html#gga03bfec859eac87be20f8952c1eb89de0a729b73e662dbdb24d2f92290e2b58aa4',1,'PAUSE_BUTTON():&#160;game.h'],['../pause__button_8h.html#a6518ed5cb03ba4bcd3c735a21ec20fc5',1,'pause_button():&#160;pause_button.h']]],
  ['pause_5fbutton_2eh',['pause_button.h',['../pause__button_8h.html',1,'']]],
  ['pause_5fgame',['pause_game',['../game_8c.html#ab61ef2b2ee56aa3ce324415be6268ee9',1,'pause_game(Game *game):&#160;game.c'],['../group__game__static.html#gab61ef2b2ee56aa3ce324415be6268ee9',1,'pause_game(Game *game):&#160;game_static.h']]],
  ['pb2base',['PB2BASE',['../vbe_8c.html#a68b87c2339cb305d66b69b5551b96c73',1,'vbe.c']]],
  ['pb2off',['PB2OFF',['../vbe_8c.html#a70c65ed4c6d71865daa96d31befb33fd',1,'vbe.c']]],
  ['penalize',['penalize',['../group__timer.html#gaed9d92c668d200b110489f14fedd5145',1,'penalize(Timer *timer, unsigned short minutes):&#160;timer.c'],['../group__timer.html#gaed9d92c668d200b110489f14fedd5145',1,'penalize(Timer *timer, unsigned short minutes):&#160;timer.c']]],
  ['phys',['phys',['../structmmap__t.html#aa6ac1ee0e0fadea4a4f85b48c8359ae4',1,'mmap_t']]],
  ['physbaseptr',['PhysBasePtr',['../struct____attribute____.html#a852a4f68cfbabf08df197128e137bde6',1,'__attribute__']]],
  ['play_5fbutton',['play_button',['../play__button_8h.html#af185cef0ce6700485cceb8238f09fbf0',1,'play_button.h']]],
  ['play_5fbutton_2eh',['play_button.h',['../play__button_8h.html',1,'']]],
  ['play_5fgame',['play_game',['../game_8c.html#ad0c5f097a4f61034196c68c9d82b0fd8',1,'play_game(Game *game):&#160;game.c'],['../group__game__static.html#gad0c5f097a4f61034196c68c9d82b0fd8',1,'play_game(Game *game):&#160;game_static.h']]],
  ['player_5fnames',['player_names',['../struct_menu.html#a37342617c7042909759827737191b43c',1,'Menu']]],
  ['players',['players',['../struct_game.html#a8ec76f283f1f511acd4b7f29994321eb',1,'Game']]],
  ['print_5fcontroller_5finfo',['print_controller_info',['../group__vbe.html#ga725e468e9f547a1326adffbb31692883',1,'print_controller_info(vbe_info_block_t *vib_p, uint16_t *vbe_modes, unsigned nbr_vbe_modes):&#160;vbe.c'],['../group__vbe.html#ga725e468e9f547a1326adffbb31692883',1,'print_controller_info(vbe_info_block_t *vib_p, uint16_t *vbe_modes, unsigned nbr_vbe_modes):&#160;vbe.c']]],
  ['proj_2ec',['proj.c',['../proj_8c.html',1,'']]]
];
