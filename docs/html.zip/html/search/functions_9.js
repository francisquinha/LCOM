var searchData=
[
  ['pause_5fgame',['pause_game',['../game_8c.html#ab61ef2b2ee56aa3ce324415be6268ee9',1,'pause_game(Game *game):&#160;game.c'],['../group__game__static.html#gab61ef2b2ee56aa3ce324415be6268ee9',1,'pause_game(Game *game):&#160;game_static.h']]],
  ['penalize',['penalize',['../group__timer.html#gaed9d92c668d200b110489f14fedd5145',1,'penalize(Timer *timer, unsigned short minutes):&#160;timer.c'],['../group__timer.html#gaed9d92c668d200b110489f14fedd5145',1,'penalize(Timer *timer, unsigned short minutes):&#160;timer.c']]],
  ['play_5fgame',['play_game',['../game_8c.html#ad0c5f097a4f61034196c68c9d82b0fd8',1,'play_game(Game *game):&#160;game.c'],['../group__game__static.html#gad0c5f097a4f61034196c68c9d82b0fd8',1,'play_game(Game *game):&#160;game_static.h']]],
  ['print_5fcontroller_5finfo',['print_controller_info',['../group__vbe.html#ga725e468e9f547a1326adffbb31692883',1,'print_controller_info(vbe_info_block_t *vib_p, uint16_t *vbe_modes, unsigned nbr_vbe_modes):&#160;vbe.c'],['../group__vbe.html#ga725e468e9f547a1326adffbb31692883',1,'print_controller_info(vbe_info_block_t *vib_p, uint16_t *vbe_modes, unsigned nbr_vbe_modes):&#160;vbe.c']]]
];
