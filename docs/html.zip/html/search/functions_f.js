var searchData=
[
  ['wait_5fvalid_5frtc',['wait_valid_rtc',['../rtc_8c.html#afc27b4d49e1d5b25388f3aa51d58cc46',1,'wait_valid_rtc():&#160;rtc.c'],['../group__rtc__static.html#gafc27b4d49e1d5b25388f3aa51d58cc46',1,'wait_valid_rtc():&#160;rtc_static.h']]]
];
