var searchData=
[
  ['y',['y',['../struct_mouse.html#acf519f948c524cbd13b89471f6712c0c',1,'Mouse']]],
  ['y_5fmake_5fcode',['Y_MAKE_CODE',['../group__i8042.html#ga7a6c5353885c82ec8b84b6ae202b85f4',1,'i8042.h']]],
  ['y_5fxpm',['Y_xpm',['../letters_8h.html#a7a264a70f27da36b305d76c9ed56c46f',1,'letters.h']]],
  ['ycharsize',['YCharSize',['../struct____attribute____.html#acb93d86860efea5c87e3c2950f39123e',1,'__attribute__']]],
  ['year',['year',['../struct_date_time.html#ad4405d29a9c7fddd9c2af4606b0c22fe',1,'DateTime']]],
  ['yresolution',['YResolution',['../struct____attribute____.html#aa91385451d974d9c33978062e22d39e2',1,'__attribute__']]]
];
