var searchData=
[
  ['b_5fmake_5fcode',['B_MAKE_CODE',['../group__i8042.html#ga58f0a599636c98b9659110cd345f497c',1,'i8042.h']]],
  ['b_5fxpm',['B_xpm',['../letters_8h.html#a190f8f05509e595b163c9ad9a425b7ce',1,'letters.h']]],
  ['backg_5fbuffer',['backg_buffer',['../struct_graphics.html#a15c51edc95f9f565478690e05e3882a9',1,'Graphics']]],
  ['background_2eh',['background.h',['../background_8h.html',1,'']]],
  ['banksize',['BankSize',['../struct____attribute____.html#aa1307567cbc12f9c5c724b7457be14ad',1,'__attribute__']]],
  ['bar_5fxpm',['bar_xpm',['../numbers_8h.html#aa404890a9d9fc130bb580158676dcae0',1,'numbers.h']]],
  ['bcd2dec',['bcd2dec',['../rtc_8c.html#aa786cd9eaa6155ecd5f471ac9642d21e',1,'bcd2dec(unsigned long bcd):&#160;rtc.c'],['../group__rtc__static.html#gaa786cd9eaa6155ecd5f471ac9642d21e',1,'bcd2dec(unsigned long bcd):&#160;rtc_static.h']]],
  ['bit',['BIT',['../group__i8042.html#ga3a8ea58898cb58fc96013383d39f482c',1,'BIT():&#160;i8042.h'],['../group__i8254.html#ga3a8ea58898cb58fc96013383d39f482c',1,'BIT():&#160;i8254.h'],['../group__rtc.html#ga3a8ea58898cb58fc96013383d39f482c',1,'BIT():&#160;rtc.h'],['../group__vbe.html#ga3a8ea58898cb58fc96013383d39f482c',1,'BIT():&#160;vbe.h']]],
  ['bits_5fper_5fpixel',['bits_per_pixel',['../video__gr_8c.html#a89fa3fb58e975d148fcb2413e24b78a1',1,'video_gr.c']]],
  ['bitsperpixel',['BitsPerPixel',['../struct____attribute____.html#abd9c59af53589a54188bb57ada5c5f26',1,'__attribute__']]],
  ['bluefieldposition',['BlueFieldPosition',['../struct____attribute____.html#ada852d5ed926757d24b5038a38e6292c',1,'__attribute__']]],
  ['bluemasksize',['BlueMaskSize',['../struct____attribute____.html#ab5967602a79dcb7f0061195ffdaaa47a',1,'__attribute__']]],
  ['bnknumberofimagepages',['BnkNumberOfImagePages',['../struct____attribute____.html#ad5820084f2b821b85a635df8394f0d9e',1,'__attribute__']]],
  ['break_5fcode',['break_code',['../struct_keyboard.html#ad3f4d6d20a9dd3394490283c7b9f41a2',1,'Keyboard']]],
  ['button',['Button',['../group__game.html#ga03bfec859eac87be20f8952c1eb89de0',1,'game.h']]],
  ['button_5fgap',['button_gap',['../struct_graphics.html#a17143b5fc77de4a615a8a492a62bcf2a',1,'Graphics']]],
  ['button_5fheight',['button_height',['../struct_graphics.html#aa3f8e7e783086d4fb6014b0bb7be286e',1,'Graphics']]],
  ['button_5fwidth',['button_width',['../struct_graphics.html#a61bb8361c921b4b278f74d25b08da294',1,'Graphics']]],
  ['byte_5fcounter',['byte_counter',['../struct_mouse.html#a0032445b8cb78b97202bafd4e8209865',1,'Mouse']]],
  ['bytes',['bytes',['../struct_mouse.html#af140ebd79c04a03075c2abb301f81af6',1,'Mouse']]],
  ['bytesperscanline',['BytesPerScanLine',['../struct____attribute____.html#a3c9eb4b107ecee102c6e63f9054ede06',1,'__attribute__']]]
];
