var searchData=
[
  ['unsubscribe_5fint',['unsubscribe_int',['../group__dispatcher.html#ga6713a9c6933446688c42c4c4c79a3f9e',1,'unsubscribe_int(int *hook_id):&#160;dispatcher.c'],['../group__dispatcher.html#ga6713a9c6933446688c42c4c4c79a3f9e',1,'unsubscribe_int(int *hook_id):&#160;dispatcher.c']]],
  ['update_5fhighscores',['update_highscores',['../group__highscore.html#ga466d042109f4c4e4f9ee8730cbd1f1d0',1,'update_highscores(HighScore *highscores[10], unsigned int new_score, unsigned short new_name[5], DateTime *new_datetime):&#160;highscore.c'],['../group__highscore.html#ga466d042109f4c4e4f9ee8730cbd1f1d0',1,'update_highscores(HighScore *highscores[10], unsigned int new_score, unsigned short new_name[5], DateTime *new_datetime):&#160;highscore.c']]]
];
