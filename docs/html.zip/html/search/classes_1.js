var searchData=
[
  ['datetime',['DateTime',['../struct_date_time.html',1,'']]]
];
