var searchData=
[
  ['interrupt_5floop',['interrupt_loop',['../group__dispatcher.html#gadf49473d49ca7c0f4550d40e7c8b7a42',1,'interrupt_loop(int irq_set, Handler int_handler, Handler app_handler, long *arg):&#160;dispatcher.c'],['../group__dispatcher.html#gadf49473d49ca7c0f4550d40e7c8b7a42',1,'interrupt_loop(int irq_set, Handler int_handler, Handler app_handler, long *arg):&#160;dispatcher.c']]]
];
