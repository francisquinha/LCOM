var searchData=
[
  ['u_5fmake_5fcode',['U_MAKE_CODE',['../group__i8042.html#ga47b98e658fc1eb7daca4668e044671e1',1,'i8042.h']]],
  ['u_5fxpm',['U_xpm',['../letters_8h.html#a34c59849b9590511c122f96245ff9de2',1,'letters.h']]],
  ['uip_5fregister_5fa',['UIP_REGISTER_A',['../group__rtc.html#gae0a72be822d5c1dc4b76a890890dda01',1,'rtc.h']]],
  ['unsubscribe_5fint',['unsubscribe_int',['../group__dispatcher.html#ga6713a9c6933446688c42c4c4c79a3f9e',1,'unsubscribe_int(int *hook_id):&#160;dispatcher.c'],['../group__dispatcher.html#ga6713a9c6933446688c42c4c4c79a3f9e',1,'unsubscribe_int(int *hook_id):&#160;dispatcher.c']]],
  ['update_5fhighscores',['update_highscores',['../group__highscore.html#ga466d042109f4c4e4f9ee8730cbd1f1d0',1,'update_highscores(HighScore *highscores[10], unsigned int new_score, unsigned short new_name[5], DateTime *new_datetime):&#160;highscore.c'],['../group__highscore.html#ga466d042109f4c4e4f9ee8730cbd1f1d0',1,'update_highscores(HighScore *highscores[10], unsigned int new_score, unsigned short new_name[5], DateTime *new_datetime):&#160;highscore.c']]]
];
