var searchData=
[
  ['i8042',['i8042',['../group__i8042.html',1,'']]],
  ['i8042_2eh',['i8042.h',['../i8042_8h.html',1,'']]],
  ['i8254',['i8254',['../group__i8254.html',1,'']]],
  ['i8254_2eh',['i8254.h',['../i8254_8h.html',1,'']]],
  ['i_5fmake_5fcode',['I_MAKE_CODE',['../group__i8042.html#gaf4cebea19650faeb67baf53cc6e432af',1,'i8042.h']]],
  ['i_5fxpm',['I_xpm',['../letters_8h.html#a636bd196088b9015a7d40dc5fda8bf7a',1,'letters.h']]],
  ['images_2ec',['images.c',['../images_8c.html',1,'']]],
  ['images_2eh',['images.h',['../images_8h.html',1,'']]],
  ['info',['info',['../struct_mouse.html#a7312e70bc9a8c4885a1eb8df5abccc0d',1,'Mouse']]],
  ['interrupt_5floop',['interrupt_loop',['../group__dispatcher.html#gadf49473d49ca7c0f4550d40e7c8b7a42',1,'interrupt_loop(int irq_set, Handler int_handler, Handler app_handler, long *arg):&#160;dispatcher.c'],['../group__dispatcher.html#gadf49473d49ca7c0f4550d40e7c8b7a42',1,'interrupt_loop(int irq_set, Handler int_handler, Handler app_handler, long *arg):&#160;dispatcher.c']]]
];
