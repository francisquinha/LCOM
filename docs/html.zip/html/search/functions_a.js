var searchData=
[
  ['read_5fxpm',['read_xpm',['../group__read__xpm.html#ga87bd140b1b1b28386f37ebac5c9b9d2e',1,'read_xpm(char *map[], int *wd, int *ht):&#160;read_xpm.c'],['../group__read__xpm.html#ga87bd140b1b1b28386f37ebac5c9b9d2e',1,'read_xpm(char *map[], int *width, int *height):&#160;read_xpm.c']]],
  ['remove_5fcard',['remove_card',['../game_8c.html#a140124a4cd336d62ade776b270523715',1,'remove_card(Game *game, char *base, char *origin, unsigned short index):&#160;game.c'],['../group__game__static.html#ga140124a4cd336d62ade776b270523715',1,'remove_card(Game *game, char *base, char *origin, unsigned short index):&#160;game_static.h']]],
  ['remove_5fcards',['remove_cards',['../game_8c.html#ae41752cc6757b74ea7e82c2d1c812a10',1,'game.c']]],
  ['remove_5fframe',['remove_frame',['../game_8c.html#aa195f2326a13ffb56a4a7e89e1372568',1,'remove_frame(Game *game, char *base, char *origin, unsigned short index):&#160;game.c'],['../group__game__static.html#gaa195f2326a13ffb56a4a7e89e1372568',1,'remove_frame(Game *game, char *base, char *origin, unsigned short index):&#160;game_static.h']]],
  ['remove_5fframes',['remove_frames',['../game_8c.html#ad2b2c971c1c28ca43669b762dc8fa781',1,'remove_frames(Game *game):&#160;game.c'],['../group__game__static.html#gad2b2c971c1c28ca43669b762dc8fa781',1,'remove_frames(Game *game):&#160;game_static.h']]],
  ['reset_5fgamestate',['reset_gamestate',['../game_8c.html#a6e38fededb0607928efb107b670b0a46',1,'reset_gamestate(GameState *gamestate):&#160;game.c'],['../group__game__static.html#ga6e38fededb0607928efb107b670b0a46',1,'reset_gamestate(GameState *gamestate):&#160;game_static.h']]],
  ['reset_5fmenu',['reset_menu',['../group__menu.html#gaa59b5ecb59f2ac71635e1eba5a7f2f85',1,'reset_menu(Menu *menu):&#160;menu.c'],['../group__menu.html#gaa59b5ecb59f2ac71635e1eba5a7f2f85',1,'reset_menu(Menu *menu):&#160;menu.c']]],
  ['reset_5ftimer',['reset_timer',['../group__timer.html#gaa7df10c7bf98827fec53b86fb1dadbbd',1,'reset_timer(Timer *timer):&#160;timer.c'],['../group__timer.html#gaa7df10c7bf98827fec53b86fb1dadbbd',1,'reset_timer(Timer *timer):&#160;timer.c']]],
  ['run_5fgame',['run_game',['../group__game.html#ga22613a4ed426179d00643f6bf2d90320',1,'run_game():&#160;game.c'],['../group__game.html#ga22613a4ed426179d00643f6bf2d90320',1,'run_game():&#160;game.c']]]
];
