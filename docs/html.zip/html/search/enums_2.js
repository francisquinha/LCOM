var searchData=
[
  ['state',['State',['../group__game.html#ga5d74787dedbc4e11c1ab15bf487e61f8',1,'game.h']]]
];
